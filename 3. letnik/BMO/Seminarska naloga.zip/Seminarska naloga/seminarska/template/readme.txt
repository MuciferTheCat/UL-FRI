Postopek prevajanja latex

1. Bibtex
2. Makeindex (ce se uporablja)
3. 2x PdfLatex